export const ADD_MOVIE_NAME = "ADD_MOVIE_NAME";
export const ADD_DATE_DAY = "ADD_DATE_DAY";
export const ADD_NAME_TIME = "ADD_NAME_TIME";
export const ADD_SEATS_DATA = "ADD_SEATS_DATA";
export const ADD_TOTAL_PRICE = "ADD_TOTAL_PRICE";